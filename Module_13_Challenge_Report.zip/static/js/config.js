const API_KEY = 'pk.eyJ1IjoicGlzdG9uczIyNCIsImEiOiJja2RlaXZnZnIxNWg1MnJwOXMxeWxlZGt1In0.lI2rg44MoS3uVdB7btJvCQ'




 